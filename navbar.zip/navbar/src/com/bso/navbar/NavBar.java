package com.bso.navbar;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import main.ShadowRenderer;
import net.miginfocom.swing.MigLayout;
import com.raven.RoundRectangle;

/**
 *
 * @author Bayks One
 */
public class NavBar extends JPanel {

    private int round;
    private int shadowSize = 20;
    private int lineWidth = 160;
    private int lineHeight = 8;
    private int headerHeight = 40;
    private float shadowOpacity = 0.08f;
    private Color shadowColor = Color.BLACK;
    private int padding = 10;
    private EventListener event;

    private int index = 0;
    private int selected;
    private final JPanel itemsPanel;

    public NavBar() {
        event = (i) -> {
        };

        itemsPanel = new JPanel();
        itemsPanel.setLayout(new MigLayout("insets 0, fillx", "[sg, fill]", "[sg, fill]"));
        itemsPanel.setOpaque(false);

        round = 45;
        setOpaque(false);
        setBackground(Color.WHITE);
        setForeground(new Color(230, 230, 230));
        setPreferredSize(new Dimension(435, 190));
        setLayout(new MigLayout("al center center"));
        init();
        add(itemsPanel, "w 100%");
    }

    private void init() {
        setBorder(new EmptyBorder(headerHeight + padding, padding, lineHeight + padding * 2 + shadowSize * 2, padding + shadowSize * 2));
    }

    @Override
    protected void paintComponent(Graphics grphcs) {
        init();
        createShadow(grphcs);
        Graphics2D g2 = (Graphics2D) grphcs;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getForeground());
        g2.translate(shadowSize, shadowSize);
        g2.fill(new RoundRectangle(getWidth() - shadowSize * 2, headerHeight, round, 0).get());

        // draw the line
        int x = (getWidth() - lineWidth) / 2 - shadowSize;
        int y = getHeight() - shadowSize * 2 - padding - lineHeight;
        g2.fillRoundRect(x, y, lineWidth, lineHeight, 10, 10);
    }

    private void createShadow(Graphics grphcs) {
        Graphics2D g2 = (Graphics2D) grphcs;
        int size = shadowSize * 2;
        int x = shadowSize;
        int y = shadowSize;
        int width = getWidth() - size;
        int height = getHeight() - size;

        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(getBackground());
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.fillRoundRect(0, 0, width, height, round, round);

        //  Create Shadow
        ShadowRenderer render = new ShadowRenderer(shadowSize, shadowOpacity, shadowColor);
        g2.drawImage(render.createShadow(img), 0, 0, null);
        g2.drawImage(img, x, y, null);
    }

    public void addItem(NavBarItem item) {
        item.setIndex(index++);
        item.addActionListener((e) -> {
            setSelected(item.getIndex());
            event.selected(item.getIndex());
        });
        itemsPanel.add(item);
    }

    public void addItem(String text, String icon, String selectedIcon) {
        addItem(new NavBarItem(text, icon, selectedIcon));
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getShadowSize() {
        return shadowSize;
    }

    public void setShadowSize(int shadowSize) {
        this.shadowSize = shadowSize;
    }

    public float getShadowOpacity() {
        return shadowOpacity;
    }

    public void setShadowOpacity(float shadowOpacity) {
        this.shadowOpacity = shadowOpacity;
    }

    public Color getShadowColor() {
        return shadowColor;
    }

    public void setShadowColor(Color shadowColor) {
        this.shadowColor = shadowColor;
    }

    public int getLineWidth() {
        return lineWidth;
    }

    public void setLineWidth(int lineWidth) {
        this.lineWidth = lineWidth;
    }

    public int getLineHeight() {
        return lineHeight;
    }

    public void setLineHeight(int lineHeight) {
        this.lineHeight = lineHeight;
    }

    public int getHeaderHeight() {
        return headerHeight;
    }

    public void setHeaderHeight(int headerHeight) {
        this.headerHeight = headerHeight;
    }

    public int getPadding() {
        return padding;
    }

    public void setPadding(int padding) {
        this.padding = padding;
    }

    public EventListener getEventListener() {
        return event;
    }

    public void addEventListener(EventListener event) {
        this.event = event;
    }
    
    public void setSelected(int index) {
        for (Component c : itemsPanel.getComponents()) {
            if (c instanceof NavBarItem i) {
                i.setSelected(false);
            }
        }
        ((NavBarItem) itemsPanel.getComponents()[index]).setSelected(true);
        this.selected = index;
    }

    public int getSelected() {
        return selected;
    }
}
