package com.bso.navbar;

/**
 *
 * @author Bayks One
 */
public interface EventListener {
    public void selected(int index);
}
