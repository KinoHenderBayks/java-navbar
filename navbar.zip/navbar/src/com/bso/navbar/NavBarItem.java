package com.bso.navbar;

import java.awt.Cursor;
import java.awt.Dimension;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author Bayks One
 */
public class NavBarItem extends JButton {

    private int index;
    
    private Icon icon;
    private Icon sIcon;

    public NavBarItem(String text, String icon, String selectedIcon) {
        setText(text);
        this.icon = new ImageIcon(getClass().getResource(icon));
        this.sIcon = new ImageIcon(getClass().getResource(selectedIcon));
        setIcon(this.icon);
        setContentAreaFilled(false);
        setPreferredSize(new Dimension(50, 42));
        setBorder(new EmptyBorder(2, 1, 2, 1));
        setVerticalTextPosition(SwingConstants.BOTTOM);
        setHorizontalTextPosition(SwingConstants.CENTER);
        setIconTextGap(2);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public void setSelectedIcon(Icon selectedIcon) {
        
    }

    @Override
    public void setSelected(boolean b) {
        super.setSelected(b); 
        if (b) {
            setIcon(sIcon);
        } else {
            setIcon(icon);
        }
    }
    
    

}
